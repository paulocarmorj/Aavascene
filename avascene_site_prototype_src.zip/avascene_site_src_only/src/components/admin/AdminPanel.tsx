import React, { useState } from 'react';

const AdminPanel: React.FC = () => {
  const [activeTab, setActiveTab] = useState('dashboard');
  const [moderators, setModerators] = useState([
    { id: 1, username: 'mod_luna', email: 'mod_luna@avascene.com', status: 'Ativo' },
    { id: 2, username: 'mod_alex', email: 'mod_alex@avascene.com', status: 'Ativo' },
  ]);
  const [newModUsername, setNewModUsername] = useState('');
  const [newModEmail, setNewModEmail] = useState('');
  const [newModPassword, setNewModPassword] = useState('');

  // Dados simulados para relatórios
  const reportedContent = [
    { id: 1, type: 'Post', user: 'toxic_user22', reason: 'Conteúdo inadequado', status: 'Pendente' },
    { id: 2, type: 'Comentário', user: 'spammer123', reason: 'Spam', status: 'Revisado' },
    { id: 3, type: 'Perfil', user: 'fake_profile', reason: 'Falsificação de identidade', status: 'Removido' },
  ];

  // Dados simulados para estatísticas
  const stats = {
    users: 12458,
    posts: 45789,
    activeToday: 3254,
    reports: 28
  };

  const handleAddModerator = (e: React.FormEvent) => {
    e.preventDefault();
    if (newModUsername && newModEmail && newModPassword) {
      const newMod = {
        id: moderators.length + 1,
        username: newModUsername,
        email: newModEmail,
        status: 'Ativo'
      };
      setModerators([...moderators, newMod]);
      setNewModUsername('');
      setNewModEmail('');
      setNewModPassword('');
    }
  };

  return (
    <div className="bg-[#001f3f] min-h-screen text-white">
      <div className="max-w-6xl mx-auto px-4 py-6">
        <div className="flex justify-between items-center mb-8">
          <h1 className="text-3xl font-bold">Painel Administrativo</h1>
          <div className="text-white/60">
            Logado como <span className="text-[#00BFFF]">admin</span>
          </div>
        </div>

        {/* Tabs */}
        <div className="flex border-b border-[#003366] mb-6">
          <button
            className={`px-4 py-2 ${
              activeTab === 'dashboard' ? 'border-b-2 border-[#00BFFF] text-[#00BFFF]' : 'text-white/60'
            }`}
            onClick={() => setActiveTab('dashboard')}
          >
            Dashboard
          </button>
          <button
            className={`px-4 py-2 ${
              activeTab === 'reports' ? 'border-b-2 border-[#00BFFF] text-[#00BFFF]' : 'text-white/60'
            }`}
            onClick={() => setActiveTab('reports')}
          >
            Denúncias
          </button>
          <button
            className={`px-4 py-2 ${
              activeTab === 'moderators' ? 'border-b-2 border-[#00BFFF] text-[#00BFFF]' : 'text-white/60'
            }`}
            onClick={() => setActiveTab('moderators')}
          >
            Moderadores
          </button>
          <button
            className={`px-4 py-2 ${
              activeTab === 'settings' ? 'border-b-2 border-[#00BFFF] text-[#00BFFF]' : 'text-white/60'
            }`}
            onClick={() => setActiveTab('settings')}
          >
            Configurações
          </button>
        </div>

        {/* Dashboard */}
        {activeTab === 'dashboard' && (
          <div>
            <h2 className="text-2xl font-bold mb-6">Visão Geral</h2>
            
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
              <div className="bg-[#002a4e] rounded-xl p-4">
                <h3 className="text-white/60 mb-2">Usuários Totais</h3>
                <p className="text-3xl font-bold text-[#00BFFF]">{stats.users}</p>
              </div>
              <div className="bg-[#002a4e] rounded-xl p-4">
                <h3 className="text-white/60 mb-2">Posts Totais</h3>
                <p className="text-3xl font-bold text-[#E6007E]">{stats.posts}</p>
              </div>
              <div className="bg-[#002a4e] rounded-xl p-4">
                <h3 className="text-white/60 mb-2">Usuários Ativos Hoje</h3>
                <p className="text-3xl font-bold text-[#FFD700]">{stats.activeToday}</p>
              </div>
              <div className="bg-[#002a4e] rounded-xl p-4">
                <h3 className="text-white/60 mb-2">Denúncias Pendentes</h3>
                <p className="text-3xl font-bold text-[#FF6B6B]">{stats.reports}</p>
              </div>
            </div>

            <h2 className="text-2xl font-bold mb-4">Atividade Recente</h2>
            <div className="bg-[#002a4e] rounded-xl p-4">
              <p className="text-white/60">Nenhuma atividade recente para exibir.</p>
            </div>
          </div>
        )}

        {/* Reports */}
        {activeTab === 'reports' && (
          <div>
            <h2 className="text-2xl font-bold mb-6">Denúncias</h2>
            
            <div className="bg-[#002a4e] rounded-xl overflow-hidden">
              <table className="w-full">
                <thead className="bg-[#003366]">
                  <tr>
                    <th className="py-3 px-4 text-left">ID</th>
                    <th className="py-3 px-4 text-left">Tipo</th>
                    <th className="py-3 px-4 text-left">Usuário</th>
                    <th className="py-3 px-4 text-left">Motivo</th>
                    <th className="py-3 px-4 text-left">Status</th>
                    <th className="py-3 px-4 text-left">Ações</th>
                  </tr>
                </thead>
                <tbody>
                  {reportedContent.map(report => (
                    <tr key={report.id} className="border-t border-[#003366]">
                      <td className="py-3 px-4">{report.id}</td>
                      <td className="py-3 px-4">{report.type}</td>
                      <td className="py-3 px-4">{report.user}</td>
                      <td className="py-3 px-4">{report.reason}</td>
                      <td className="py-3 px-4">
                        <span className={`px-2 py-1 rounded-full text-xs ${
                          report.status === 'Pendente' ? 'bg-[#FFD700]/20 text-[#FFD700]' :
                          report.status === 'Revisado' ? 'bg-[#00BFFF]/20 text-[#00BFFF]' :
                          'bg-[#E6007E]/20 text-[#E6007E]'
                        }`}>
                          {report.status}
                        </span>
                      </td>
                      <td className="py-3 px-4">
                        <button className="text-[#00BFFF] hover:underline mr-2">Ver</button>
                        <button className="text-[#E6007E] hover:underline">Remover</button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* Moderators */}
        {activeTab === 'moderators' && (
          <div>
            <h2 className="text-2xl font-bold mb-6">Gerenciar Moderadores</h2>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div className="md:col-span-2">
                <div className="bg-[#002a4e] rounded-xl overflow-hidden">
                  <table className="w-full">
                    <thead className="bg-[#003366]">
                      <tr>
                        <th className="py-3 px-4 text-left">ID</th>
                        <th className="py-3 px-4 text-left">Usuário</th>
                        <th className="py-3 px-4 text-left">Email</th>
                        <th className="py-3 px-4 text-left">Status</th>
                        <th className="py-3 px-4 text-left">Ações</th>
                      </tr>
                    </thead>
                    <tbody>
                      {moderators.map(mod => (
                        <tr key={mod.id} className="border-t border-[#003366]">
                          <td className="py-3 px-4">{mod.id}</td>
                          <td className="py-3 px-4">{mod.username}</td>
                          <td className="py-3 px-4">{mod.email}</td>
                          <td className="py-3 px-4">
                            <span className="px-2 py-1 rounded-full bg-[#00BFFF]/20 text-[#00BFFF] text-xs">
                              {mod.status}
                            </span>
                          </td>
                          <td className="py-3 px-4">
                            <button className="text-[#E6007E] hover:underline">Remover</button>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
              
              <div>
                <div className="bg-[#002a4e] rounded-xl p-4">
                  <h3 className="text-xl font-bold mb-4">Adicionar Moderador</h3>
                  <form onSubmit={handleAddModerator}>
                    <div className="mb-4">
                      <label className="block text-white/80 mb-2">Nome de Usuário</label>
                      <input
                        type="text"
                        value={newModUsername}
                        onChange={(e) => setNewModUsername(e.target.value)}
                        className="w-full p-2 rounded-lg bg-[#001f3f] border border-[#003366] text-white"
                        required
                      />
                    </div>
                    <div className="mb-4">
                      <label className="block text-white/80 mb-2">Email</label>
                      <input
                        type="email"
                        value={newModEmail}
                        onChange={(e) => setNewModEmail(e.target.value)}
                        className="w-full p-2 rounded-lg bg-[#001f3f] border border-[#003366] text-white"
                        required
                      />
                    </div>
                    <div className="mb-4">
                      <label className="block text-white/80 mb-2">Senha</label>
                      <input
                        type="password"
                        value={newModPassword}
                        onChange={(e) => setNewModPassword(e.target.value)}
                        className="w-full p-2 rounded-lg bg-[#001f3f] border border-[#003366] text-white"
                        required
                      />
                    </div>
                    <button
                      type="submit"
                      className="bg-[#00BFFF] text-white font-bold py-2 px-4 rounded-lg w-full"
                    >
                      Adicionar
                    </button>
                  </form>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Settings */}
        {activeTab === 'settings' && (
          <div>
            <h2 className="text-2xl font-bold mb-6">Configurações</h2>
            
            <div className="bg-[#002a4e] rounded-xl p-6">
              <h3 className="text-xl font-bold mb-4">Configurações Gerais</h3>
              
              <div className="space-y-4">
                <div>
                  <label className="block text-white/80 mb-2">Nome do Site</label>
                  <input
                    type="text"
                    defaultValue="AvaScene"
                    className="w-full p-2 rounded-lg bg-[#001f3f] border border-[#003366] text-white"
                  />
                </div>
                
                <div>
                  <label className="block text-white/80 mb-2">Descrição</label>
                  <textarea
                    defaultValue="Rede social para fãs do Avakin Life"
                    className="w-full p-2 rounded-lg bg-[#001f3f] border border-[#003366] text-white"
                    rows={3}
                  />
                </div>
                
                <div className="flex items-center">
                  <input
                    type="checkbox"
                    id="enableRegistration"
                    defaultChecked
                    className="mr-2"
                  />
                  <label htmlFor="enableRegistration">Permitir novos registros</label>
                </div>
                
                <div className="flex items-center">
                  <input
                    type="checkbox"
                    id="requireApproval"
                    className="mr-2"
                  />
                  <label htmlFor="requireApproval">Exigir aprovação para novos posts</label>
                </div>
                
                <button
                  className="bg-[#00BFFF] text-white font-bold py-2 px-4 rounded-lg"
                >
                  Salvar Configurações
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default AdminPanel;
