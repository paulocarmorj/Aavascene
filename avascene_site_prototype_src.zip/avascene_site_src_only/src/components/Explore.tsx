import React from 'react';
import { Link } from 'react-router-dom';

const Explore: React.FC = () => {
  // Dados simulados para a área de exploração
  const explorePosts = [
    { id: 1, category: 'Populares' },
    { id: 2, category: 'Moda' },
    { id: 3, category: 'Decoração' },
    { id: 4, category: 'Eventos' },
    { id: 5, category: 'Locais' },
    { id: 6, category: 'Looks' },
    { id: 7, category: 'Festas' },
    { id: 8, category: 'Amigos' },
    { id: 9, category: 'Casas' },
    { id: 10, category: 'Clubes' },
    { id: 11, category: 'Outfits' },
    { id: 12, category: 'Cenários' },
  ];

  return (
    <div className="bg-[#001f3f] min-h-screen pb-16">
      <div className="max-w-xl mx-auto pt-4 px-4">
        {/* Search Bar */}
        <div className="mb-6">
          <div className="bg-[#002a4e] rounded-full flex items-center px-4 py-2">
            <span className="text-white/60 mr-2">🔍</span>
            <input
              type="text"
              placeholder="Buscar"
              className="bg-transparent border-none outline-none text-white w-full"
            />
          </div>
        </div>

        {/* Categories */}
        <div className="flex overflow-x-auto space-x-3 pb-4 mb-6 scrollbar-hide">
          {['Todos', 'Moda', 'Decoração', 'Eventos', 'Locais', 'Looks', 'Festas'].map((category, index) => (
            <div 
              key={index} 
              className={`flex-shrink-0 px-4 py-2 rounded-full ${
                index === 0 ? 'bg-[#00BFFF] text-white' : 'bg-[#002a4e] text-white/80'
              }`}
            >
              {category}
            </div>
          ))}
        </div>

        {/* Explore Grid */}
        <div className="grid grid-cols-2 gap-2">
          {explorePosts.map(post => (
            <div key={post.id} className="aspect-square bg-[#002a4e] rounded-lg overflow-hidden relative">
              <div className="absolute inset-0 flex items-center justify-center">
                <div className="text-white/30 text-sm">{post.category}</div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default Explore;
