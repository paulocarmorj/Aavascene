import React from 'react';
import { Link } from 'react-router-dom';

const Videos: React.FC = () => {
  // Dados simulados para a área de vídeos
  const currentVideo = {
    id: 1,
    username: 'Luna_Love',
    caption: 'loving this view 🌙',
    likes: 104,
    comments: 23,
    shares: 8,
    music: 'Night Lights'
  };

  return (
    <div className="bg-[#001f3f] min-h-screen">
      {/* Vídeo em tela cheia */}
      <div className="relative h-screen w-full bg-[#001a33] flex items-center justify-center">
        {/* Overlay de gradiente para melhorar legibilidade do texto */}
        <div className="absolute inset-0 bg-gradient-to-b from-transparent via-transparent to-[#001f3f]/70"></div>
        
        {/* Conteúdo do vídeo */}
        <div className="absolute inset-0 flex items-center justify-center">
          <div className="text-white/30 text-lg">Conteúdo do vídeo</div>
        </div>
        
        {/* Informações do usuário (parte inferior) */}
        <div className="absolute bottom-20 left-4 right-4 z-10">
          <div className="flex items-center mb-3">
            <div className="w-10 h-10 rounded-full bg-[#003366] mr-3"></div>
            <h3 className="text-xl font-bold text-[#00BFFF]">{currentVideo.username}</h3>
          </div>
          
          <p className="text-white mb-2">{currentVideo.caption}</p>
          
          <div className="flex items-center text-white/80">
            <span className="text-sm">🎵 {currentVideo.music}</span>
          </div>
        </div>
        
        {/* Botões de interação (lado direito) */}
        <div className="absolute right-4 bottom-1/3 flex flex-col items-center space-y-6">
          <div className="flex flex-col items-center">
            <button className="text-[#E6007E] text-2xl mb-1">♥</button>
            <span className="text-white text-sm">{currentVideo.likes}</span>
          </div>
          
          <div className="flex flex-col items-center">
            <button className="text-white text-2xl mb-1">💬</button>
            <span className="text-white text-sm">{currentVideo.comments}</span>
          </div>
          
          <div className="flex flex-col items-center">
            <button className="text-white text-2xl mb-1">🔗</button>
            <span className="text-white text-sm">{currentVideo.shares}</span>
          </div>
        </div>
        
        {/* Indicador de deslizar */}
        <div className="absolute bottom-4 left-0 right-0 flex justify-center">
          <div className="text-white/60 text-sm">Deslize para o próximo vídeo</div>
        </div>
      </div>
    </div>
  );
};

export default Videos;
