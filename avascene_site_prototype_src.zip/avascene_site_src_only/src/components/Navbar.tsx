import React from 'react';
import { Link, useNavigate, useLocation } from 'react-router-dom';

interface NavbarProps {
  isLoggedIn: boolean;
}

const Navbar: React.FC<NavbarProps> = ({ isLoggedIn }) => {
  const navigate = useNavigate();
  const location = useLocation();
  
  const handleLogout = () => {
    localStorage.removeItem('isLoggedIn');
    localStorage.removeItem('isAdmin');
    localStorage.removeItem('username');
    navigate('/');
  };

  // Don't show navbar on landing, login, register pages
  if (['/login', '/register', '/'].includes(location.pathname)) {
    return null;
  }

  const username = localStorage.getItem('username') || '';

  return (
    <nav className="bg-[#001f3f] border-b border-[#003366] py-3 px-4 sticky top-0 z-50">
      <div className="max-w-6xl mx-auto flex justify-between items-center">
        {/* Logo */}
        <Link to="/feed" className="text-2xl font-bold">
          <span className="text-[#FF6B6B]">Ava</span>
          <span className="text-[#00BFFF]">Scene</span>
        </Link>

        {/* Navigation Links */}
        <div className="hidden md:flex space-x-6">
          <Link 
            to="/feed" 
            className={`text-white hover:text-[#00BFFF] transition-colors ${
              location.pathname === '/feed' ? 'text-[#00BFFF]' : ''
            }`}
          >
            Feed
          </Link>
          <Link 
            to="/explore" 
            className={`text-white hover:text-[#00BFFF] transition-colors ${
              location.pathname === '/explore' ? 'text-[#00BFFF]' : ''
            }`}
          >
            Explorar
          </Link>
          <Link 
            to="/videos" 
            className={`text-white hover:text-[#00BFFF] transition-colors ${
              location.pathname === '/videos' ? 'text-[#00BFFF]' : ''
            }`}
          >
            Vídeos
          </Link>
          <Link 
            to="/trends" 
            className={`text-white hover:text-[#00BFFF] transition-colors ${
              location.pathname === '/trends' ? 'text-[#00BFFF]' : ''
            }`}
          >
            Trends
          </Link>
          <Link 
            to="/messages" 
            className={`text-white hover:text-[#00BFFF] transition-colors ${
              location.pathname === '/messages' ? 'text-[#00BFFF]' : ''
            }`}
          >
            Mensagens
          </Link>
        </div>

        {/* User Menu */}
        <div className="flex items-center space-x-4">
          <Link 
            to="/profile" 
            className="text-white hover:text-[#00BFFF] transition-colors"
          >
            {username}
          </Link>
          <button 
            onClick={handleLogout}
            className="text-white/70 hover:text-white transition-colors"
          >
            Sair
          </button>
        </div>
      </div>

      {/* Mobile Navigation */}
      <div className="md:hidden flex justify-between mt-3 border-t border-[#003366] pt-3">
        <Link 
          to="/feed" 
          className={`text-white hover:text-[#00BFFF] transition-colors ${
            location.pathname === '/feed' ? 'text-[#00BFFF]' : ''
          }`}
        >
          Feed
        </Link>
        <Link 
          to="/explore" 
          className={`text-white hover:text-[#00BFFF] transition-colors ${
            location.pathname === '/explore' ? 'text-[#00BFFF]' : ''
          }`}
        >
          Explorar
        </Link>
        <Link 
          to="/videos" 
          className={`text-white hover:text-[#00BFFF] transition-colors ${
            location.pathname === '/videos' ? 'text-[#00BFFF]' : ''
          }`}
        >
          Vídeos
        </Link>
        <Link 
          to="/trends" 
          className={`text-white hover:text-[#00BFFF] transition-colors ${
            location.pathname === '/trends' ? 'text-[#00BFFF]' : ''
          }`}
        >
          Trends
        </Link>
        <Link 
          to="/messages" 
          className={`text-white hover:text-[#00BFFF] transition-colors ${
            location.pathname === '/messages' ? 'text-[#00BFFF]' : ''
          }`}
        >
          Mensagens
        </Link>
      </div>
    </nav>
  );
};

export default Navbar;
