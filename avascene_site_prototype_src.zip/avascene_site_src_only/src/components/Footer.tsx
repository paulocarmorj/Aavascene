import React from 'react';

const Footer: React.FC = () => {
  return (
    <footer className="bg-[#001f3f] border-t border-[#003366] py-4 mt-auto">
      <div className="max-w-6xl mx-auto px-4 text-center">
        <p className="text-white/60 text-sm">
          Powered By Zendrien + Paulo Carmo
        </p>
      </div>
    </footer>
  );
};

export default Footer;
