import React from 'react';
import { Link } from 'react-router-dom';

// Dados simulados para o feed
const mockPosts = [
  {
    id: 1,
    username: 'Luna_Love',
    avatar: '/assets/images/avatar1.png',
    image: '/assets/images/post1.jpg',
    caption: 'Amando esse visual noturno 🌙 #AvakinLife #NightVibes',
    likes: 1024,
    comments: 48,
    timestamp: '2 horas atrás'
  },
  {
    id: 2,
    username: 'Alex_2022',
    avatar: '/assets/images/avatar2.png',
    image: '/assets/images/post2.jpg',
    caption: 'Festa incrível na mansão! Quem mais esteve lá? #AvakinParty #VIPEvent',
    likes: 758,
    comments: 32,
    timestamp: '5 horas atrás'
  },
  {
    id: 3,
    username: 'StarryNight',
    avatar: '/assets/images/avatar3.png',
    image: '/assets/images/post3.jpg',
    caption: 'Novo apartamento decorado! O que acharam? #AvaDecor #InteriorDesign',
    likes: 1532,
    comments: 87,
    timestamp: '1 dia atrás'
  },
  {
    id: 4,
    username: 'Fashion_Queen',
    avatar: '/assets/images/avatar4.png',
    image: '/assets/images/post4.jpg',
    caption: 'Look do dia para o festival! #AvakinFashion #OOTD',
    likes: 2103,
    comments: 112,
    timestamp: '2 dias atrás'
  }
];

const Feed: React.FC = () => {
  return (
    <div className="bg-[#001f3f] min-h-screen pb-16">
      <div className="max-w-xl mx-auto pt-4 px-4">
        {/* Stories */}
        <div className="flex overflow-x-auto space-x-4 pb-4 mb-6 scrollbar-hide">
          {Array.from({ length: 8 }).map((_, index) => (
            <div key={index} className="flex-shrink-0">
              <div className="w-16 h-16 rounded-full bg-gradient-to-r from-[#E6007E] to-[#00BFFF] p-[2px]">
                <div className="w-full h-full rounded-full bg-[#003366] flex items-center justify-center">
                  <div className="w-[90%] h-[90%] rounded-full bg-[#002a4e]"></div>
                </div>
              </div>
              <p className="text-white text-xs text-center mt-1 truncate w-16">
                user_{index + 1}
              </p>
            </div>
          ))}
        </div>

        {/* Posts */}
        <div className="space-y-6">
          {mockPosts.map(post => (
            <div key={post.id} className="bg-[#002a4e] rounded-xl overflow-hidden shadow-lg">
              {/* Post Header */}
              <div className="flex items-center p-3">
                <div className="w-10 h-10 rounded-full bg-[#003366] mr-3"></div>
                <Link to="/profile" className="font-medium text-white">
                  {post.username}
                </Link>
                <div className="ml-auto text-white/60 text-sm">
                  {post.timestamp}
                </div>
              </div>

              {/* Post Image */}
              <div className="aspect-square bg-[#001f3f] flex items-center justify-center">
                <div className="text-white/30 text-sm">Imagem do post</div>
              </div>

              {/* Post Actions */}
              <div className="flex items-center p-3 border-b border-[#003366]">
                <button className="text-[#E6007E] mr-4">
                  ♥ {post.likes}
                </button>
                <button className="text-[#00BFFF] mr-4">
                  💬 {post.comments}
                </button>
                <button className="text-white/60">
                  🔗
                </button>
                <button className="text-white/60 ml-auto">
                  🔖
                </button>
              </div>

              {/* Post Caption */}
              <div className="p-3">
                <p className="text-white">
                  <span className="font-medium">{post.username}</span>{' '}
                  {post.caption}
                </p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default Feed;
