import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';

const Register: React.FC = () => {
  const [username, setUsername] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [inviteCode, setInviteCode] = useState('');
  const [error, setError] = useState('');
  const navigate = useNavigate();

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    // Basic validation
    if (password !== confirmPassword) {
      setError('As senhas não coincidem.');
      return;
    }

    if (password.length < 6) {
      setError('A senha deve ter pelo menos 6 caracteres.');
      return;
    }

    // Mock registration for demo
    localStorage.setItem('isLoggedIn', 'true');
    localStorage.setItem('isAdmin', 'false');
    localStorage.setItem('username', username);
    navigate('/feed');
  };

  return (
    <div className="min-h-screen flex flex-col items-center justify-center bg-[#001f3f] p-4">
      <div className="w-full max-w-md">
        <div className="text-center mb-8">
          <h1 className="text-5xl font-bold mb-2">
            <span className="text-[#FF6B6B]">Ava</span>
            <span className="text-[#00BFFF]">Scene</span>
          </h1>
          <h2 className="text-xl text-white/80">Criar uma nova conta</h2>
        </div>

        {error && (
          <div className="bg-red-500/20 border border-red-500 text-white p-3 rounded-lg mb-4">
            {error}
          </div>
        )}

        <form onSubmit={handleSubmit} className="bg-[#002a4e] rounded-xl shadow-lg p-6">
          <div className="mb-4">
            <label htmlFor="username" className="block text-white/80 mb-2">
              Nome de Usuário
            </label>
            <input
              type="text"
              id="username"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              className="w-full p-3 rounded-lg bg-[#001f3f] border border-[#003366] text-white focus:outline-none focus:ring-2 focus:ring-[#00BFFF]"
              required
            />
          </div>

          <div className="mb-4">
            <label htmlFor="email" className="block text-white/80 mb-2">
              Email
            </label>
            <input
              type="email"
              id="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="w-full p-3 rounded-lg bg-[#001f3f] border border-[#003366] text-white focus:outline-none focus:ring-2 focus:ring-[#00BFFF]"
              required
            />
          </div>

          <div className="mb-4">
            <label htmlFor="password" className="block text-white/80 mb-2">
              Senha
            </label>
            <input
              type="password"
              id="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="w-full p-3 rounded-lg bg-[#001f3f] border border-[#003366] text-white focus:outline-none focus:ring-2 focus:ring-[#00BFFF]"
              required
            />
          </div>

          <div className="mb-4">
            <label htmlFor="confirmPassword" className="block text-white/80 mb-2">
              Confirmar Senha
            </label>
            <input
              type="password"
              id="confirmPassword"
              value={confirmPassword}
              onChange={(e) => setConfirmPassword(e.target.value)}
              className="w-full p-3 rounded-lg bg-[#001f3f] border border-[#003366] text-white focus:outline-none focus:ring-2 focus:ring-[#00BFFF]"
              required
            />
          </div>

          <div className="mb-6">
            <label htmlFor="inviteCode" className="block text-white/80 mb-2">
              Código de Convidado (opcional)
            </label>
            <input
              type="text"
              id="inviteCode"
              value={inviteCode}
              onChange={(e) => setInviteCode(e.target.value)}
              className="w-full p-3 rounded-lg bg-[#001f3f] border border-[#003366] text-white focus:outline-none focus:ring-2 focus:ring-[#00BFFF]"
            />
          </div>

          <button
            type="submit"
            className="btn-secondary w-full mb-4"
          >
            CRIAR CONTA
          </button>

          <div className="text-center text-white/60">
            <p>
              Já tem uma conta?{' '}
              <Link to="/login" className="text-[#00BFFF] hover:underline">
                Entrar
              </Link>
            </p>
          </div>
        </form>
      </div>
      
      {/* Footer */}
      <div className="mt-8 text-sm text-white/60">
        Powered By Zendrien + Paulo Carmo
      </div>
    </div>
  );
};

export default Register;
