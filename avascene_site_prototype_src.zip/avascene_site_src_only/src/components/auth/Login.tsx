import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';

const Login: React.FC = () => {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const navigate = useNavigate();

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    // Admin login check
    if (username === 'admin' && password === '32488333') {
      // Store admin status in localStorage
      localStorage.setItem('isLoggedIn', 'true');
      localStorage.setItem('isAdmin', 'true');
      localStorage.setItem('username', 'admin');
      navigate('/admin');
      return;
    }

    // Mock authentication for demo
    if (username && password.length >= 6) {
      // Store user info in localStorage for demo purposes
      localStorage.setItem('isLoggedIn', 'true');
      localStorage.setItem('isAdmin', 'false');
      localStorage.setItem('username', username);
      navigate('/feed');
    } else {
      setError('Nome de usuário ou senha inválidos. A senha deve ter pelo menos 6 caracteres.');
    }
  };

  return (
    <div className="min-h-screen flex flex-col items-center justify-center bg-[#001f3f] p-4">
      <div className="w-full max-w-md">
        <div className="text-center mb-8">
          <h1 className="text-5xl font-bold mb-2">
            <span className="text-[#FF6B6B]">Ava</span>
            <span className="text-[#00BFFF]">Scene</span>
          </h1>
          <h2 className="text-xl text-white/80">Entrar na sua conta</h2>
        </div>

        {error && (
          <div className="bg-red-500/20 border border-red-500 text-white p-3 rounded-lg mb-4">
            {error}
          </div>
        )}

        <form onSubmit={handleSubmit} className="bg-[#002a4e] rounded-xl shadow-lg p-6">
          <div className="mb-4">
            <label htmlFor="username" className="block text-white/80 mb-2">
              Nome de Usuário/Email
            </label>
            <input
              type="text"
              id="username"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              className="w-full p-3 rounded-lg bg-[#001f3f] border border-[#003366] text-white focus:outline-none focus:ring-2 focus:ring-[#00BFFF]"
              required
            />
          </div>

          <div className="mb-6">
            <label htmlFor="password" className="block text-white/80 mb-2">
              Senha
            </label>
            <input
              type="password"
              id="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="w-full p-3 rounded-lg bg-[#001f3f] border border-[#003366] text-white focus:outline-none focus:ring-2 focus:ring-[#00BFFF]"
              required
            />
          </div>

          <button
            type="submit"
            className="btn-primary w-full mb-4"
          >
            ENTRAR
          </button>

          <div className="text-center text-white/60">
            <p>
              Não tem uma conta?{' '}
              <Link to="/register" className="text-[#00BFFF] hover:underline">
                Criar Conta
              </Link>
            </p>
          </div>
        </form>
      </div>
      
      {/* Footer */}
      <div className="mt-8 text-sm text-white/60">
        Powered By Zendrien + Paulo Carmo
      </div>
    </div>
  );
};

export default Login;
