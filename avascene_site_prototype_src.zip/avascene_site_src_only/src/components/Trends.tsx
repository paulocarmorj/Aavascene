import React from 'react';
import { Link } from 'react-router-dom';

const Trends: React.FC = () => {
  // Dados simulados para a área de trends
  const trendingTopics = [
    { id: 1, hashtag: '#AvakinOOTD', posts: '15,2 mil', image: '/assets/images/trend1.jpg' },
    { id: 2, hashtag: '#AvaDecor', posts: '7.890', image: '/assets/images/trend2.jpg' },
    { id: 3, hashtag: '#AvakinEvents', posts: '12,5 mil', image: '/assets/images/trend3.jpg' },
    { id: 4, hashtag: '#AvakinTravel', posts: '9.002', image: '/assets/images/trend4.jpg' },
    { id: 5, hashtag: '#AvaBuilds', posts: '6.711', image: '/assets/images/trend5.jpg' },
    { id: 6, hashtag: '#AvakinFashion', posts: '18,3 mil', image: '/assets/images/trend6.jpg' },
    { id: 7, hashtag: '#AvakinParty', posts: '11,4 mil', image: '/assets/images/trend7.jpg' },
    { id: 8, hashtag: '#AvakinCouple', posts: '8.256', image: '/assets/images/trend8.jpg' },
  ];

  return (
    <div className="bg-[#001f3f] min-h-screen pb-16">
      <div className="max-w-xl mx-auto pt-4 px-4">
        {/* Header */}
        <h1 className="text-3xl font-bold text-[#FFD700] mb-6">Em Alta</h1>

        {/* Trending Topics */}
        <div className="space-y-4">
          {trendingTopics.map(topic => (
            <div key={topic.id} className="bg-[#002a4e] rounded-xl overflow-hidden shadow-lg">
              <div className="flex items-center p-4">
                {/* Thumbnail */}
                <div className="w-16 h-16 bg-[#003366] rounded-lg mr-4 flex-shrink-0"></div>
                
                {/* Content */}
                <div className="flex-grow">
                  <h3 className="text-xl font-bold text-white">{topic.hashtag}</h3>
                  <p className="text-[#00BFFF]">{topic.posts} posts</p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default Trends;
