import React from 'react';
import { Link } from 'react-router-dom';

const Profile: React.FC = () => {
  // Dados simulados do perfil
  const profile = {
    username: 'Luna_Love',
    bio: 'just a night owl 🦉 exploring the virtuiworld',
    posts: 12,
    followers: 2580,
    following: 315,
    images: [
      '/assets/images/post1.jpg',
      '/assets/images/post2.jpg',
      '/assets/images/post3.jpg',
      '/assets/images/post4.jpg',
      '/assets/images/post5.jpg',
      '/assets/images/post6.jpg',
    ]
  };

  return (
    <div className="bg-[#001f3f] min-h-screen pb-16">
      <div className="max-w-xl mx-auto pt-4 px-4">
        {/* Profile Header */}
        <div className="flex flex-col items-center mb-8">
          {/* Avatar */}
          <div className="w-24 h-24 rounded-full bg-gradient-to-r from-[#4B0082] to-[#483D8B] p-[2px] mb-4">
            <div className="w-full h-full rounded-full bg-[#002a4e]"></div>
          </div>
          
          {/* Username */}
          <h1 className="text-2xl font-bold text-white mb-4">{profile.username}</h1>
          
          {/* Stats */}
          <div className="flex justify-between w-full max-w-xs mb-4">
            <div className="text-center">
              <p className="text-2xl font-bold text-[#FFD700]">{profile.posts}</p>
              <p className="text-white/60 text-sm">POSTS</p>
            </div>
            <div className="text-center">
              <p className="text-2xl font-bold text-[#00BFFF]">{profile.followers}</p>
              <p className="text-white/60 text-sm">FOLLOWERS</p>
            </div>
            <div className="text-center">
              <p className="text-2xl font-bold text-[#00BFFF]">{profile.following}</p>
              <p className="text-white/60 text-sm">FOLLOWING</p>
            </div>
          </div>
          
          {/* Edit Profile Button */}
          <button className="bg-[#00BFFF] text-white font-bold py-2 px-6 rounded-full w-full max-w-xs mb-4">
            EDITAR PERFIL
          </button>
          
          {/* Bio */}
          <p className="text-white text-center max-w-xs mb-6">{profile.bio}</p>
        </div>
        
        {/* Posts Grid */}
        <div className="grid grid-cols-3 gap-1">
          {Array.from({ length: 9 }).map((_, index) => (
            <div key={index} className="aspect-square bg-[#002a4e] flex items-center justify-center">
              <div className="text-white/30 text-xs">Post {index + 1}</div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default Profile;
