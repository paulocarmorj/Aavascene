import React from 'react';
import { Link } from 'react-router-dom';

const Messages: React.FC = () => {
  // Dados simulados para a área de mensagens
  const conversations = [
    { 
      id: 1, 
      username: 'Luna_Love', 
      lastMessage: 'Hi! How\'s it going?', 
      time: '2 min', 
      unread: true 
    },
    { 
      id: 2, 
      username: 'Alex_2022', 
      lastMessage: 'Sounds good 👍', 
      time: '20 min', 
      unread: false 
    },
    { 
      id: 3, 
      username: 'StarryNight', 
      lastMessage: 'Are you coming to the...', 
      time: '1 h', 
      unread: true 
    },
    { 
      id: 4, 
      username: 'Moon_Gazer', 
      lastMessage: 'I\'ll let you know tomorrow', 
      time: '2 h', 
      unread: false 
    },
    { 
      id: 5, 
      username: 'DreamChaser', 
      lastMessage: 'Thanks! 😊', 
      time: 'Apr 17', 
      unread: false 
    },
  ];

  return (
    <div className="bg-[#001f3f] min-h-screen pb-16">
      <div className="max-w-xl mx-auto pt-4 px-4">
        {/* Header */}
        <div className="flex items-center justify-between mb-6">
          <h1 className="text-2xl font-bold text-white">Mensagens</h1>
          <button className="text-[#00BFFF]">
            + Nova
          </button>
        </div>

        {/* Search Bar */}
        <div className="mb-6">
          <div className="bg-[#002a4e] rounded-full flex items-center px-4 py-2">
            <span className="text-white/60 mr-2">🔍</span>
            <input
              type="text"
              placeholder="Buscar"
              className="bg-transparent border-none outline-none text-white w-full"
            />
          </div>
        </div>

        {/* Conversations List */}
        <div className="space-y-2">
          {conversations.map(convo => (
            <div 
              key={convo.id} 
              className={`flex items-center p-3 rounded-xl ${
                convo.unread ? 'bg-[#002a4e]' : 'bg-[#001f3f] border border-[#003366]'
              }`}
            >
              {/* Avatar */}
              <div className={`w-12 h-12 rounded-full ${
                convo.unread ? 'bg-[#00BFFF]' : 'bg-[#003366]'
              } p-[2px] mr-3`}>
                <div className="w-full h-full rounded-full bg-[#002a4e]"></div>
              </div>
              
              {/* Content */}
              <div className="flex-grow">
                <div className="flex justify-between">
                  <h3 className="font-bold text-white">{convo.username}</h3>
                  <span className="text-white/60 text-sm">{convo.time}</span>
                </div>
                <p className={`text-sm ${
                  convo.unread ? 'text-white' : 'text-white/60'
                }`}>
                  {convo.lastMessage}
                </p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default Messages;
