import React from 'react';
import { Link } from 'react-router-dom';
import landingBackground from '../assets/images/landing_background.png';
import avasceneModels from '../assets/images/avascene_models.png';

const LandingPage: React.FC = () => {
  return (
    <div className="min-h-screen flex flex-col items-center justify-center relative overflow-hidden">
      {/* Background image with overlay */}
      <div 
        className="absolute inset-0 z-0" 
        style={{
          backgroundImage: `url(${landingBackground})`,
          backgroundSize: 'cover',
          backgroundPosition: 'center',
          backgroundRepeat: 'no-repeat',
        }}
      >
        <div className="absolute inset-0 bg-[#001f3f] bg-opacity-70"></div>
      </div>

      {/* Content */}
      <div className="z-10 flex flex-col items-center justify-center px-4 text-center">
        {/* Logo */}
        <h1 className="text-6xl font-bold mb-4">
          <span className="text-[#FF6B6B]">Ava</span>
          <span className="text-[#00BFFF]">Scene</span>
        </h1>

        {/* Tagline */}
        <h2 className="text-2xl md:text-3xl font-light mb-6 text-white">
          Sua vida social Avakin começa aqui!
        </h2>
        
        {/* Featured Image */}
        <div className="w-full max-w-md mb-8">
          <img 
            src={avasceneModels} 
            alt="AvaScene Models" 
            className="w-full h-auto object-contain"
          />
        </div>

        {/* Buttons */}
        <div className="flex flex-col sm:flex-row gap-4 w-full max-w-xs sm:max-w-md">
          <Link 
            to="/login" 
            className="btn-primary w-full text-center"
          >
            ENTRAR
          </Link>
          <Link 
            to="/register" 
            className="btn-secondary w-full text-center"
          >
            CRIAR CONTA
          </Link>
        </div>
      </div>

      {/* Footer */}
      <div className="absolute bottom-4 text-sm text-white/60 z-10">
        Powered By Zendrien + Paulo Carmo
      </div>
    </div>
  );
};

export default LandingPage;
